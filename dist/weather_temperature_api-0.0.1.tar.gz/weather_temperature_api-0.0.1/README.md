get temprature api
